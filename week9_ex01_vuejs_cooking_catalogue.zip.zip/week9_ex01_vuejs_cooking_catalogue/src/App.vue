<template>
  <div>
    <header class="header">
      <h1>Cooking Masterclass</h1>
      <p>Wishlist: {{ wishlistCount }}</p>
    </header>

    <div class="catalogue">
      <CourseCard
        v-for="item in courses"
        :key="item.id"
        :course="item"
        @save-course="addToWishlist"
      />
    </div>
  </div>
</template>

<script>
import CourseCard from "./components/CourseCard.vue";

export default {
  components: { CourseCard },

  data() {
    return {
      wishlistCount: 0,

      courses: [
        {
          id: 1,
          title: "Italian Pasta Basics",
          chef: "Chef Mario",
          price: 250,
          level: "Beginner",
          available: true,
        },
        {
          id: 2,
          title: "Sushi Masterclass",
          chef: "Chef Sato",
          price: 500,
          level: "Advanced",
          available: false,
        },
        {
          id: 3,
          title: "Baking Basics",
          chef: "Chef Emma",
          price: 300,
          level: "Intermediate",
          available: true,
        },
      ],
    };
  },

  methods: {
    addToWishlist() {
      this.wishlistCount++;
    },
  },
};
</script>

<style>
.header {
  display: flex;
  justify-content: space-between;
  padding: 15px;
  background: #222;
  color: white;
}

.catalogue {
  display: flex;
  gap: 20px;
  flex-wrap: wrap;
  padding: 20px;
}
</style>