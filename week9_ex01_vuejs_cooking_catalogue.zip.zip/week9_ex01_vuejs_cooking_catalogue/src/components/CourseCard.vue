<template>
  <div class="card">
    <h2>{{ course.title }}</h2>

    <p><strong>Chef:</strong> {{ course.chef }}</p>
    <p><strong>Level:</strong> {{ course.level }}</p>
    <p><strong>Price:</strong> R{{ course.price }}</p>

    <p v-if="!course.available" class="sold">
      SOLD OUT
    </p>

    <button
      v-if="course.available"
      @click="saveCourse"
    >
      Save to Wishlist
    </button>
  </div>
</template>

<script>
export default {
  props: ["course"],

  methods: {
    saveCourse() {
      this.$emit("save-course");
    },
  },
};
</script>

<style>
.card {
  border: 1px solid #ccc;
  padding: 15px;
  width: 220px;
  border-radius: 10px;
}

.sold {
  color: red;
  font-weight: bold;
}
</style>
button {
  padding: 8px;
  background: green;
  color: white;
  border: none;
  cursor: pointer;
  margin-top: 10px;
}

button:hover {
  background: darkgreen;
}
