<template>
  <div class="summary">
    <h2>Price Summary</h2>

    <p>Subtotal: R{{ subtotal.toFixed(2) }}</p>
    <p>Tax (15%): R{{ tax.toFixed(2) }}</p>

    <h3>Grand Total: R{{ total.toFixed(2) }}</h3>
  </div>
</template>

<script setup>
defineProps({
  subtotal: Number,
  tax: Number,
  total: Number,
});
</script>