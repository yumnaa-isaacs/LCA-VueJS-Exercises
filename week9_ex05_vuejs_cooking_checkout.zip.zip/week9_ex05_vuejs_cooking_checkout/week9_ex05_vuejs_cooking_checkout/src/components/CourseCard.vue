<template>
  <div class="card">
    <h3>{{ course.name }}</h3>
    <p>Price: R{{ course.price }}</p>

    <button
      v-if="!course.soldOut"
      class="add-btn"
      @click="$emit('add-course', course)"
    >
      Add to Cart
    </button>

    <button v-else class="sold-btn" disabled>
      Sold Out
    </button>
  </div>
</template>

<script setup>
defineProps({
  course: Object,
});

defineEmits(["add-course"]);
</script>