<template>

  <Header :total="filteredProperties.length" />

  <div class="controls">
    <input v-model="search" placeholder="Search properties..." />

    <select v-model="sortOrder">
      <option value="low">Price Low → High</option>
      <option value="high">Price High → Low</option>
    </select>
  </div>

  <div class="grid">
    <PropertyCard
      v-for="property in filteredProperties"
      :key="property.id"
      :property="property"
      @bookmark="bookmark(property)"
    />
  </div>

</template>

<script>
import Header from "./components/Header.vue"
import PropertyCard from "./components/PropertyCard.vue"

export default {
  components: {
    Header,
    PropertyCard
  },

  data() {
    return {
      search: "",
      sortOrder: "low",
      bookmarks: [],

      properties: [
        {
          id: 1,
          title: "Luxury Apartment",
          location: "Cape Town",
          price: 2500,
          type: "Apartment",
          available: true,
          image: "https://picsum.photos/300/200?1"
        },
        {
          id: 2,
          title: "Beach House",
          location: "Camps Bay",
          price: 5500,
          type: "House",
          available: false,
          image: "https://picsum.photos/300/200?2"
        },
        {
          id: 3,
          title: "Modern Studio",
          location: "Sea Point",
          price: 1800,
          type: "Studio",
          available: true,
          image: "https://picsum.photos/300/200?3"
        },
        {
          id: 4,
          title: "Family Home",
          location: "Durbanville",
          price: 3200,
          type: "House",
          available: true,
          image: "https://picsum.photos/300/200?4"
        }
      ]
    }
  },

  computed: {
    filteredProperties() {
      let results = this.properties.filter(p =>
        p.title.toLowerCase().includes(this.search.toLowerCase()) ||
        p.location.toLowerCase().includes(this.search.toLowerCase())
      )

      if (this.sortOrder === "low") {
        results.sort((a, b) => a.price - b.price)
      } else {
        results.sort((a, b) => b.price - a.price)
      }

      return results
    }
  },

  methods: {
    bookmark(property) {
      alert(property.title + " added to favourites!")
    }
  }
}
</script>

<style>
body {
  font-family: Arial;
  margin: 0;
  background: #f4f4f4;
}

.controls {
  display: flex;
  gap: 10px;
  padding: 20px;
}

input, select {
  padding: 10px;
}

.grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 20px;
  padding: 20px;
}
</style>