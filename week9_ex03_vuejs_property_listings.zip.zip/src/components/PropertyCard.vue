<template>
  <div class="card">

    <div v-if="!property.available" class="badge">
      Not Available
    </div>

    <img :src="property.image" />

    <h2>{{ property.title }}</h2>
    <p>{{ property.location }}</p>
    <p>R {{ property.price }}</p>
    <p>{{ property.type }}</p>

    <button @click="$emit('bookmark')">
      ⭐ Favourite
    </button>

  </div>
</template>

<script>
export default {
  props: ["property"]
}
</script>

<style scoped>
.card {
  border: 1px solid #ddd;
  padding: 15px;
  border-radius: 10px;
  position: relative;
}

img {
  width: 100%;
  height: 180px;
  object-fit: cover;
}

.badge {
  position: absolute;
  top: 10px;
  right: 10px;
  background: red;
  color: white;
  padding: 5px;
}
</style>