<template>
  <header class="header">
    <h1>Homes & Beyond</h1>
    <p>{{ total }} Properties Available</p>
  </header>
</template>

<script>
export default {
  props: ["total"]
}
</script>

<style scoped>
.header {
  background: #0d6efd;
  color: white;
  text-align: center;
  padding: 20px;
}
</style>