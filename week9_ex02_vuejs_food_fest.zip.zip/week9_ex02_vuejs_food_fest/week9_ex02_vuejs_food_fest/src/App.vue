<script setup>
import { ref } from 'vue'
import TicketCard from './components/TicketCard.vue'

const tickets = ref([
  {
    id: 1,
    name: 'Bronze',
    price: 150,
    benefits: [
      'General Entry',
      'Access to food stalls',
      'Live music area'
    ],
    featured: false
  },
  {
    id: 2,
    name: 'Silver',
    price: 300,
    benefits: [
      'Priority Entry',
      'Free Drink Voucher',
      'Reserved Seating'
    ],
    featured: true
  },
  {
    id: 3,
    name: 'Gold',
    price: 500,
    benefits: [
      'VIP Access',
      'Meet the Chefs',
      'Exclusive Lounge'
    ],
    featured: false
  }
])
</script>

<template>
  <header>
    <h1>Cape Town Food Fest 2025</h1>
    <p>
      Enjoy amazing food, live music,
      and unforgettable experiences.
    </p>
  </header>

  <section class="tickets">
    <TicketCard
      v-for="ticket in tickets"
      :key="ticket.id"
      :ticket="ticket"
    />
  </section>
</template>

<style>
body {
  margin: 0;
  font-family: Arial, sans-serif;
}

header {
  text-align: center;
  padding: 2rem;
}

.tickets {
  display: flex;
  gap: 20px;
  justify-content: center;
  flex-wrap: wrap;
}

/* Responsive */
@media (max-width: 768px) {
  .tickets {
    flex-direction: column;
    align-items: center;
  }
}
</style>