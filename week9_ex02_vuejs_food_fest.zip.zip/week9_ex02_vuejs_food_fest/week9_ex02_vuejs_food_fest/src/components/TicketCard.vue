<script setup>
import { ref } from 'vue'

defineProps({
  ticket: Object
})

const favourite = ref(false)

function toggleFavourite() {
  favourite.value = !favourite.value
}
</script>

<template>
  <div class="ticket-card" :class="{ featured: ticket.featured }">

    <!-- Featured badge -->
    <span v-if="ticket.featured" class="featured-badge">
      ⭐ Featured
    </span>

    <!-- Ticket name -->
    <h2>{{ ticket.name }}</h2>

    <!-- Ticket price -->
    <h3>R{{ ticket.price }}</h3>

    <!-- Benefits list -->
    <ul>
      <li
        v-for="benefit in ticket.benefits"
        :key="benefit"
      >
        {{ benefit }}
      </li>
    </ul>

    <!-- Favourite button -->
    <button class="fav-btn" @click="toggleFavourite">
      {{ favourite ? '❤️ Favourite' : '🤍 Favourite' }}
    </button>

    <!-- CTA button -->
    <button class="cta-btn">
      Notify Me
    </button>

  </div>
</template>

<style scoped>
.ticket-card {
  width: 280px;
  padding: 20px;
  border-radius: 10px;
  background: white;
  box-shadow: 0 2px 8px rgba(0,0,0,0.2);
  transition: all 0.3s ease;
}

.ticket-card:hover {
  transform: translateY(-8px);
  box-shadow: 0 10px 20px rgba(0,0,0,0.2);
}

/* Featured styling */
.featured {
  border: 3px solid gold;
}

/* Featured label */
.featured-badge {
  display: inline-block;
  margin-bottom: 10px;
  font-weight: bold;
  color: goldenrod;
}

/* List styling */
ul {
  padding-left: 20px;
}

/* Buttons */
button {
  width: 100%;
  padding: 10px;
  margin-top: 10px;
  cursor: pointer;
  border-radius: 5px;
  border: none;
}

/* Favourite button */
.fav-btn {
  background: #f2f2f2;
  transition: transform 0.2s;
}

.fav-btn:hover {
  transform: scale(1.05);
}

/* CTA button */
.cta-btn {
  background: #ff6600;
  color: white;
}
</style>